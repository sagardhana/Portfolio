function z = func1_HW1_7(t)
z = sin(t).*sin(3.*t);
end