function d = distance_HW1_5(x,y)

a = x(1)-y(1);
b = x(2)-y(2);
c = x(3)-y(3);

d = sqrt(a*a+b*b+c*c);

end 
