function v = rocketvel_HW1_3(t)


switch t
    
    case t * (0 <= t & t <= 8)
        v = 10*t^2-5*t;
    case t*(8 < t & t <= 16)
        v = 624-5*t;
    case t*(16< t & t <= 26)
        v = 36*t+12*(t-16)^2;
    case t*(t>26)
        v=2136*exp(-0.1*(t-26));
    case t*(t<0)
        v = 0;
end

end

