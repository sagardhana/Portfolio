t = [-5:50];
v = [];
for i = 1:56
   
    v(i) = rocketvel_HW1_3(t(i)); 
    
end

figure
plot(t,v)