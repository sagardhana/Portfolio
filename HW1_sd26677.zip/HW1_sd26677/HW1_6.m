[x,y] = meshgrid(0:0.02*pi:2*pi);
z = cos(3.*x).*sin(2.*y).*exp(-0.5.*((x-pi).^2+(y-pi).^2));

figure
surf(x,y,z);
colormap hsv
colorbar

figure
[C,h] = contour(x,y,z);
clabel(C,h);