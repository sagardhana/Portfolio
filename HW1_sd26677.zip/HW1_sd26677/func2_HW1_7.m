function z = func2_HW1_7(t)
z = cos(t).*sin(6.*t);
end