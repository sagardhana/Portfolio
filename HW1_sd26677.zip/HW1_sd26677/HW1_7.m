t = [0:0.02*pi:2*pi];

y1 = func1_HW1_7(t);
y2 = func2_HW1_7(t);


figure
plot(t,y1)
hold on;
plot(t,y2)