disp('Enter a number greater than ZERO.')
disp('To get a sum of all numbers enter -999')
sum =0;
x=0;

while (x+999 > 10^-10)
sum = sum+x;
x = input(' ');

end

sum